<!DOCTYPE html>
<html lang="en">
<head>
  <title>CSS Template</title>
  <meta charset="utf-8">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * {
      box-sizing: border-box;
    }

    body, html {
      height: 100%;
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    /* Style the fixed header */
    header {
      background-color:black;
      padding:auto;
      text-align: center;
      font-size: 35px;
      color: white;
      position: fixed; /* Fixed position at the top */
      top: 0;
      left: 0;
      width: 100%;
      z-index: 10; /* Ensure it stays on top of the other content */
    }

    /* Add padding-top to the body to make room for the fixed header */
    body {
      padding-top: 100px; /* Adjust based on the header height */
    }

    /* Layout the three containers */
    section {
      display: flex;
      height: 100%;
    }

    /* Left container */
    .left-container {
      width: 20%;
      background-color:white;
    border:solid 5px lavender;
      padding: 10px;
      overflow-y: auto;
      height: 100%;
    }
.left-container::-webkit-scrollbar {
     display:none;
    }

    /* Center container */
    .center-container {
      width: 60%;
      background-color:white;
      padding: 20px;
      height: 100%;
      overflow-y: auto;
    }
.center-container::-webkit-scrollbar {
     display:none;
    }

    /* Right container */
    .right-container {
      width: 20%;
      background-color:white;
      border:solid 5px lavender;
      padding: 10px;
      overflow-y: auto;
      height: 100%;
    }
 .right-container::-webkit-scrollbar {
     display:none;
    }

    /* Style the footer */
    footer {
      background-color: #777;
      padding: 10px;
      text-align: center;
      color: white;
      margin-top: auto;
    }
 .container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center; /* Center the items horizontally */
        }

        /* Styling each floating box */
        .box {
            width: 200px;        /* Fixed width */
            height: 150px;       /* Fixed height */
            padding: 20px;
            margin: 10px;
            background-color:white;
            border:none;
            border-radius: 10px;
            text-align: center;
            resize: both;        /* Make the box resizable */
            overflow: auto;      /* Allow overflow when resized */
            box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.6); /* Box shadow */
        }
  .box::-webkit-scrollbar {
           display:none;
        }

 /* Styling the container for the search bar */
        .search-container {
            display: flex;
            justify-content: center; /* Center the search bar */
            align-items: center;
            margin-top: 50px;
        }

        /* Styling the input field */
        .search-input {
            width: 300px;
            height: 40px;
            padding-left: 40px; /* Add space for the search icon */
            border-radius: 20px;
            border: 1px solid #ccc;
            font-size: 16px;
            outline: none;
            padding-right: 20px; /* Space on the right for the icon */
        }

        /* Search icon styling */
        .search-icon {
            position: absolute;
            left: 15px;
            font-size: 18px;
            color: #888;
        }
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color:transparent;
}

.topnav a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #212121;
  color: white;
}

.topnav a.active {
  background-color:darkblue;
  color: white;
}

 .search-container {
  float: center;
background:white;
}

 input[type=text] {
  padding: 6px  50px;
  margin-top: 8px;
  font-size: 17px;
  border:solid 1px grey;
}

 .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-bottom: 5px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}
 .search-container label {
  
  padding: 6px 10px;
  margin-top: 8px;
  margin-right:-5px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

 .search-container button:hover {
  background: #ccc;
}
    /* Responsive layout for small screens */
    @media (max-width: 600px) {
      section {
        flex-direction: column;
        margin-left: 0;
      }

      .left-container, .right-container {
        width: 100%;
      }

      .center-container {
        width: 100%;
      }
.box {
                flex: 0 0 100%;     /* Stack the boxes vertically */
                width: 100%;        /* Full width on small screens */
                height: auto;       /* Allow height to adjust based on content */
            }
 .search-input {
                width: 80%;
            }

 .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
    }
div.gallery {
  border: 1px solid #ccc;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

* {
  box-sizing: border-box;
}

.responsive {
  padding: 0 6px;
  float: left;
  width: 24.99999%;
}

@media only screen and (max-width: 700px) {
  .responsive {
    width: 49.99999%;
    margin: 6px 0;
  }
}

@media only screen and (max-width: 500px) {
  .responsive {
    width: 100%;
  }
}

.clearfix:after {
  content: "";
  display: table;
  clear: both;
}

/* Styling for the nav container */
        .main-header {
            background-color:black; /* Dark background */
            overflow: hidden; /* Ensures content doesn't overflow */
            font-size: 18px;
            position: sticky;
            top: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        /* Styling for the left side of the navbar */
        .header-left-section {
            display: flex;
            align-items: center;
        }

        .header-left-section div {
            margin-right: 30px;
            color: white;
        }

        /* Styling for the navbar links */
        .header-nav {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .header-nav li {
            display: inline;
            padding: 14px 20px;
        }

        .header-nav a {
            text-decoration: none;
            color: white;
            display: block;
            padding: 14px 20px;
            transition: background-color 0.3s;
        }

        /* Hover effect when hovering over links */
        .header-nav a:hover {
            background-color: #575757;
        }

        /* Active link styling */
        .header-nav a.active {
            background-color: darkblue;
        }

        /* Button inside the navbar */
        .login-signup-btn {
            padding: 10px 20px;
            border-radius: 5px;
            background-color: darkblue;
            color: white;
            border: none;
            cursor: pointer;
        }

        /* Custom dropdown menu styling */
        .custom-dropdown-container {
            position: relative;
            display: inline-block;
        }

        .custom-dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .custom-dropdown-container:hover .custom-dropdown-content {
            display: block;
        }

        .custom-dropdown-content select {
            width: 100%;
            padding: 8px;
            border: none;
            background-color: white;
        }

        /* Unique support icon styling */
        .support-icon {
            color: white;
            font-size: 24px;
        }

        .support-text {
            color: white;
            display: inline;
            margin-left: 5px;
        }
.row{
background:white;
  box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.6);
padding: 20px;
 margin-bottom: 20px;
}
/* Create three unequal columns that floats next to each other */
.column {
  float: left;
  padding: 10px;
}

/* Left and right column */
.column.side {
  width: 20%;
 background:white;
 width: 20%;
border-width:5px;
border-right:solid;
border-color:lavender;
height:500px;
overflow-y:scroll;
 flex-direction: column;
 justify-content: space-between;
 padding: 10px
}
.column.side::-webkit-scrollbar {
 
 display: none;

}


        .column.side button {
            margin: 5px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

/* Middle column */
.column.middle {
  width: 80%;
background:white;

}

/* Clear floats after the columns */
.row::after {
  content: "";
  display: table;
  clear: both;
}
.mysearch-container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .mysearch-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .myform-group {
            margin-bottom: 15px;
        }

        .myform-group label {
            display: block;
            margin-bottom: 5px;
        }

        .myform-group select, input[name="search_name"], input[value="Search Car"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[name="search_name"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[value="Search Car"]:hover {
            background-color: #45a049;
        }

        .year-range {
            display: flex;
            justify-content: space-between;
        }

        .year-range select {
            width: 48%;
        }  </style>
</head>
<body>

<header>
  <h2>CAR DEALERSHIP SYSTEM</h2>
<!-- Horizontal Navigation Bar -->
    <div class="main-header">
        <!-- Left side with extra content -->
        <div class="header-left-section">
            <!-- First div: Kenya Time and Total Cars -->
            <div>
                <p>Kenya Time: <span id="kenya-time"></span></p>
                <p>Total Cars: 456,787</p>
            </div>

            <!-- Second div: Login/Signup Button -->
            <div>
                <button class="login-signup-btn">Login / Signup</button>
            </div>

            <!-- Third div: Support Icon and Language Dropdown -->
            <div class="custom-dropdown-container">
                <i class="fas fa-life-ring support-icon"></i>
                <p class="support-text">Support</p>
                <div class="custom-dropdown-content">
                    <select>
                        <option value="en">English</option>
                        <option value="sw">Swahili</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Navigation links in the navbar -->
        <ul class="header-nav">
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </div>


</header>

<section>
  <div class="left-container">
    <h2>Left Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <h2>Left Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <h2>Left Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <h2>Left Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
  </div>

  <div class="center-container">

<div class="search-container">
    <form action="/action_page.php">
    <label>Search car</label>
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>

    <h1>London</h1>
   <div class="container">
        <div class="box">
 <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
    <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
    <p>London's history and culture attract millions of visitors every year, including iconic landmarks such as the Tower of London, Buckingham Palace, and the British Museum.</p>
    <p>There are also world-famous parks like Hyde Park and Regent's Park, as well as the historic West End theater district.</p>
</div>
        <div class="box">
 <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
    <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
    <p>London's history and culture attract millions of visitors every year, including iconic landmarks such as the Tower of London, Buckingham Palace, and the British Museum.</p>
    <p>There are also world-famous parks like Hyde Park and Regent's Park, as well as the historic West End theater district.</p>
</div>
        <div class="box">
 <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
    <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
    <p>London's history and culture attract millions of visitors every year, including iconic landmarks such as the Tower of London, Buckingham Palace, and the British Museum.</p>
    <p>There are also world-famous parks like Hyde Park and Regent's Park, as well as the historic West End theater district.</p></div>
    </div>




 <!-- First container with red background -->
    <div style="background-color:white; padding: 20px; margin-bottom: 20px;  box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.6);">
        <h2>Responsive Image Gallery 1</h2>
        <h4>Resize the browser window to see the effect.</h4>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_5terre.jpg">
                    <img src="img_5terre.jpg" alt="Cinque Terre" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_forest.jpg">
                    <img src="img_forest.jpg" alt="Forest" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_lights.jpg">
                    <img src="img_lights.jpg" alt="Northern Lights" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_mountains.jpg">
                    <img src="img_mountains.jpg" alt="Mountains" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div style="padding:6px;">
            <p>This example uses media queries to re-arrange the images on different screen sizes: for screens larger than 700px wide, it will show four images side by side, for screens smaller than 700px, it will show two images side by side. For screens smaller than 500px, the images will stack vertically (100%).</p>
            <p>You will learn more about media queries and responsive web design later in our CSS Tutorial.</p>
        </div>
    </div>


   <!-- 3D container with red background -->

<div class="row">
  <div class="column side">
    <h2>Controls</h2>
    <button onclick="changeOpacity(1)">Opacity 100%</button>
            <button onclick="changeOpacity(0.9)">Opacity 90%</button>
            <button onclick="changeOpacity(0.8)">Opacity 80%</button>
            <button onclick="changeOpacity(0.7)">Opacity 70%</button>
            <button onclick="changeOpacity(0.6)">Opacity 60%</button>
            <button onclick="changeOpacity(0.5)">Opacity 50%</button>
            <button onclick="changeOpacity(0.4)">Opacity 40%</button>
            <button onclick="changeOpacity(0.3)">Opacity 30%</button>
            <button onclick="changeOpacity(0.2)">Opacity 20%</button>
            <button onclick="changeOpacity(0.1)">Opacity 10%</button>
  </div>
  
  <div class="column middle">
    <h2>Main Content</h2>
    
  </div>
  
 
</div>






    <!-- Second container with red background -->
    <div style="background-color: white; padding: 20px; margin-bottom: 20px;  box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.6);">
        <h2>Responsive Image Gallery 2</h2>
        <h4>Resize the browser window to see the effect.</h4>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_5terre.jpg">
                    <img src="img_5terre.jpg" alt="Cinque Terre" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_forest.jpg">
                    <img src="img_forest.jpg" alt="Forest" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_lights.jpg">
                    <img src="img_lights.jpg" alt="Northern Lights" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_mountains.jpg">
                    <img src="img_mountains.jpg" alt="Mountains" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div style="padding:6px;">
            <p>This example uses media queries to re-arrange the images on different screen sizes: for screens larger than 700px wide, it will show four images side by side, for screens smaller than 700px, it will show two images side by side. For screens smaller than 500px, the images will stack vertically (100%).</p>
            <p>You will learn more about media queries and responsive web design later in our CSS Tutorial.</p>
        </div>
    </div>

    <!-- Third container with red background -->
    <div style="background-color:white; padding: 20px; margin-bottom: 20px;  box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.6);">
        <h2>Responsive Image Gallery 3</h2>
        <h4>Resize the browser window to see the effect.</h4>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_5terre.jpg">
                    <img src="img_5terre.jpg" alt="Cinque Terre" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_forest.jpg">
                    <img src="img_forest.jpg" alt="Forest" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_lights.jpg">
                    <img src="img_lights.jpg" alt="Northern Lights" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="img_mountains.jpg">
                    <img src="img_mountains.jpg" alt="Mountains" width="600" height="400">
                </a>
                <div class="desc">Add a description of the image here</div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div style="padding:6px;">
            <p>This example uses media queries to re-arrange the images on different screen sizes: for screens larger than 700px wide, it will show four images side by side, for screens smaller than 700px, it will show two images side by side. For screens smaller than 500px, the images will stack vertically (100%).</p>
            <p>You will learn more about media queries and responsive web design later in our CSS Tutorial.</p>
        </div>
    </div>

   
  </div>

  <div class="right-container">
   <div class="mysearch-container">
        <h2>Search Cars</h2>
        <form action="#" method="GET">
            <!-- Car Make -->
            <div class="myform-group">
                <label for="car_make">Make</label>
                <select name="car_make" id="car_make">
                    <option value="toyota">Toyota</option>
                    <option value="ford">Ford</option>
                    <option value="honda">Honda</option>
                    <option value="bmw">BMW</option>
                    <option value="audi">Audi</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="nissan">Nissan</option>
                    <option value="chevrolet">Chevrolet</option>
                </select>
            </div>

            <!-- Car Model -->
            <div class="myform-group">
                <label for="car_model">Model</label>
                <select name="car_model" id="car_model">
                    <option value="corolla">Corolla</option>
                    <option value="civic">Civic</option>
                    <option value="focus">Focus</option>
                    <option value="3series">3 Series</option>
                    <option value="a4">A4</option>
                    <option value="e-class">E-Class</option>
                    <option value="altima">Altima</option>
                    <option value="malibu">Malibu</option>
                </select>
            </div>

            <!-- Car Body Type -->
            <div class="myform-group">
                <label for="car_body_type">Body Type</label>
                <select name="car_body_type" id="car_body_type">
                    <option value="sedan">Sedan</option>
                    <option value="hatchback">Hatchback</option>
                    <option value="suv">SUV</option>
                    <option value="pickup">Pickup</option>
                    <option value="coupe">Coupe</option>
                    <option value="convertible">Convertible</option>
                </select>
            </div>

            <!-- RHD/LHD -->
            <div class="myform-group">
                <label for="rhd_lhd">RHD/LHD</label>
                <select name="rhd_lhd" id="rhd_lhd">
                    <option value="rhd">Right Hand Drive (RHD)</option>
                    <option value="lhd">Left Hand Drive (LHD)</option>
                </select>
            </div>

            <!-- Year Range -->
            <div class="myform-group year-range">
                <div>
                    <label for="year_from">From Year</label>
                    <select name="year_from" id="year_from">
                        <option value="2000">2000</option>
                        <option value="2001">2001</option>
                        <option value="2002">2002</option>
                        <option value="2003">2003</option>
                        <option value="2004">2004</option>
                        <option value="2005">2005</option>
                        <option value="2006">2006</option>
                        <option value="2007">2007</option>
                        <option value="2008">2008</option>
                        <option value="2009">2009</option>
                        <option value="2010">2010</option>
                        <option value="2011">2011</option>
                        <option value="2012">2012</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                    </select>
                </div>

                <div>
                    <label for="year_to">To Year</label>
                    <select name="year_to" id="year_to">
                        <option value="2000">2000</option>
                        <option value="2001">2001</option>
                        <option value="2002">2002</option>
                        <option value="2003">2003</option>
                        <option value="2004">2004</option>
                        <option value="2005">2005</option>
                        <option value="2006">2006</option>
                        <option value="2007">2007</option>
                        <option value="2008">2008</option>
                        <option value="2009">2009</option>
                        <option value="2010">2010</option>
                        <option value="2011">2011</option>
                        <option value="2012">2012</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                    </select>
                </div>
            </div>

            <!-- Search by Name -->
            <div class="myform-group">
                <label for="search_name_input">Search by Name</label>
                <input type="text" id="search_name_input" name="search_name" placeholder="Search by car name...">
            </div>

            <!-- Submit Button -->
            <div class="myform-group">
                <input type="submit" value="Search Car" id="search_car_button">
            </div>
        </form>
    </div>

    <h2>Right Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <h2>Right Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <h2>Right Container</h2>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
    <p>Content goes here.</p>
  </div>
</section>

<footer>
  <p>Footer Content</p>
</footer>

<script>
        // JavaScript to get and display Kenya's time
        function getKenyaTime() {
            var kenyaTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Nairobi" });
            document.getElementById("kenya-time").textContent = kenyaTime;
        }

        // Run the function to display Kenya time
        setInterval(getKenyaTime, 1000);  // Update time every second
    </script>
</body>
</html>
