const mysql = require('mysql2');

// Create a database connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'cardealership'
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to the database for email checking');
});

// Function to check if email exists
const checkEmailExistence = (email) => {
  return new Promise((resolve, reject) => {
    const query = 'SELECT COUNT(*) AS count FROM users WHERE email = ?';
    connection.query(query, [email], (err, results) => {
      if (err) {
        console.error('Error checking email existence:', err.stack);
        reject(err);
      } else {
        const count = results[0].count;
        resolve(count > 0); // Returns true if email exists, false otherwise
      }
    });
  });
};

module.exports = { checkEmailExistence };
