const mysql = require('mysql2');
const bcrypt = require('bcrypt');

// Create a database connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'cardealership'
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to the database');

  // Create the users table if it doesn't exist
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(50) NOT NULL,
      email VARCHAR(100) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      hashedpassword VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
  `;
  
  connection.query(createTableQuery, (err) => {
    if (err) {
      console.error('Error creating users table:', err.stack);
    } else {
      console.log('Users table is ready!');
    }
  });
});

// Function to insert data with hashed password
const insertData = (name, email, password) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Hash the password
      const saltRounds = 10;
      const hashedPassword = await bcrypt.hash(password, saltRounds);

      const query = 'INSERT INTO users (name, email, password, hashedpassword) VALUES (?, ?, ?, ?)';
      
      connection.query(query, [name, email, password, hashedPassword], (err, results) => {
        if (err) {
          console.error('Error inserting data:', err.stack);
          reject(err);
        } else {
          console.log('Data inserted:', results);
          resolve(results);
        }
      });
    } catch (err) {
      console.error('Error hashing password:', err.stack);
      reject(err);
    }
  });
};

module.exports = { insertData };
