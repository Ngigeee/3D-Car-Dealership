const { check } = require("express-validator");

const validateForm = [
  check('name')
    .notEmpty().withMessage('Name should not be empty')
    .isAlpha().withMessage('Name should only contain alphabets')
    .isLength({ min: 5 }).withMessage('Name should be at least 5 characters long')
    .trim()
    .escape(),

  check('email')
    .notEmpty().withMessage('Email should not be empty')
    .isEmail().withMessage('Please enter a valid email')
    .normalizeEmail()
    .trim()
    .escape(),

  check('password')
    .isLength({ min: 8 }).withMessage('Password should be at least 8 characters long')
    .matches(/[A-Z]/).withMessage('Password should contain at least one uppercase letter')
    .matches(/[a-z]/).withMessage('Password should contain at least one lowercase letter')
    .matches(/[0-9]/).withMessage('Password should contain at least one number')
    .matches(/[\!\@\#\$\%\^\&\*\(\)\_\+\-\=\[\]\{\}\|\;:,"\.<>\?\/\\]/).withMessage('Password should contain at least one special character')
    .trim()
    .escape()
];

module.exports = validateForm;
